package com.example.hotspot;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class MainActivity extends AppCompatActivity {

    int i=0;

    TextView User , pass ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        User = findViewById(R.id.username);
        pass= findViewById(R.id.pass);

        i++;
        if (i==1) {

            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + this.getPackageName()));
            startActivity(intent);
        }


        if (isWriteStoragePermissionGranted())
            hotspot();
        else
            AskPermission();


    }

    public void AskPermission(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)){
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            }else{
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "Permission granted", Toast.LENGTH_SHORT).show();
                    // call your method
                    hotspot();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                    finish();
//                    stop_permission++;
//                    if (stop_permission==2)
//                        finish();
//                    else
//                        AskPermission();
                }
                return;
            }
        }
    }

    public  boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)== PackageManager.PERMISSION_GRANTED) {
                return true;
            } else
            {
//                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            Toast.makeText(this, "default Permission is granted1 on below android 6", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

   public void hotspot()
   {
       WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
       final WifiManager.LocalOnlyHotspotReservation[] mReservation = new WifiManager.LocalOnlyHotspotReservation[1];
       if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
           assert manager != null;
           manager.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {

               @SuppressLint("SetTextI18n")
               @Override
               public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                   super.onStarted(reservation);
//                   Timber.d("Wifi Hotspot is on now , reservation is : %s", reservation.toString());
                   mReservation[0] = reservation;
                 String  key = mReservation[0].getWifiConfiguration().preSharedKey;
                   String ussid = mReservation[0].getWifiConfiguration().SSID;

                   Toast.makeText(MainActivity.this, ussid +"//"  + key, Toast.LENGTH_SHORT).show();

                   User.setText(ussid);
                           pass.setText(key);
               }

               @Override
               public void onStopped() {
                   super.onStopped();
//                   Timber.d("onStopped: ");
               }

               @Override
               public void onFailed(int reason) {
                   super.onFailed(reason);
//                   Timber.d("onFailed: ");
               }
           }, new Handler());
       }
   }

}
